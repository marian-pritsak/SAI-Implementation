#ifndef FLEXTRUM_TYPES_H_
#define FLEXTRUM_TYPES_H_

#ifdef __cplusplus
extern "C"{
#endif

// Spectrum 1 specific HW limit
#define PORT_NUM 32
#define RIF_NUM 400 // TODO: max output for sdk_rif_iter_get
#define DEV_ID  1
// #define ACL_SIZE 100
#define NUM_OF_TC 8
#define NUM_OF_PRIO 8
#define MAX_TABLE_NAME_LEN 200

// Maps table name to P4 runtime table ID
typedef enum{
	 TABLE_PEERING_ID = 33579056,
	 TABLE_VHOST_ID = 33613359,
} flextrum_table_id_t;

// Maps action name to P4 runtime action ID
typedef enum{
	ACTION_INVALID_ID,
	TO_ROUTER_ID = 16806391,
	SET_VNET_BITMAP_ID = 16816808,
	TO_TUNNEL_ID = 16791826,
	TO_PORT_ID = 16799102,
	NOACTION_ID = 16800567,
} flextrum_action_id_t;

//---------action structs------
// struct action_NoAction_t {
// }

// struct action_set_vnet_bitmap_t {
// 	bit<12>*		vnet_bitmap;
// }

// struct action_to_tunnel_t {
// 	bit<32>*		tunnel_id;
// 	bit<32>*		underlay_dip;
// 	bit<16>*		bridge_id;
// }

// struct action_to_router_t {
// 	bit<32>*		router_pbs_id;
// }

// struct action_to_port_t {
// 	bit<32>*		port_pbs_id;
// }


#ifdef __cplusplus
}
#endif

#endif
